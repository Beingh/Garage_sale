function navigateToProduct(productPage) {
    window.location.href = productPage;
}
