Place your product images in this folder.

Image naming examples:
- charger1.jpg, charger1-2.jpg, charger1-3.jpg
- cable1.jpg, cable1-2.jpg, cable1-3.jpg
- earphone1.jpg, earphone1-2.jpg

