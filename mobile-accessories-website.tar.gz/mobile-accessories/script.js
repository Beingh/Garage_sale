function navigateToCategory(categoryPage) {
    window.location.href = categoryPage;
}

function navigateToProduct(productPage) {
    window.location.href = productPage;
}
